#include "game.h"

void game_init(void) {

}

void game_process(void) {

}
