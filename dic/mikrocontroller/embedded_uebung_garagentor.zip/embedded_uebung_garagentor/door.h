#ifndef DOOR_H
#define DOOR_H

void door_init(void);
void door_process(void);

#endif
