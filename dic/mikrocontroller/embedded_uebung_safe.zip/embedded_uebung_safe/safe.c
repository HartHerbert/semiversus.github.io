#include "safe.h"
#include "hal.h"

timer_var_t timer_safe;

// TODO: definitions

void safe_init(void) {
	timer_safe=TIMER_DISABLED;
	// TODO: initialisation
}

void safe_process(void) {
	//TODO: state machine
}
